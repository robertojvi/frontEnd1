# FE1-trabajoFinal

# Actividades realizadas:

# Roberto Vélez:
# Diseño y estructura general de sitio móvil y desktop
# Diseño y desarrollo para móvil
# Comentarios para documentación de código
# Estidos para ocultar y mostrar elementos en móvil y desktop
# Estilos para cambio entre versión móvil y desktop 


# Juliana Forero:
# Diseño y estructura general de sitio móvil y desktop
# Diseño y desarrollo para desktop 
# Comentarios para documentación de código
# Cambio de etiquetas para mejorar semántica
# Estilos para cambio entre versión móvil y desktop